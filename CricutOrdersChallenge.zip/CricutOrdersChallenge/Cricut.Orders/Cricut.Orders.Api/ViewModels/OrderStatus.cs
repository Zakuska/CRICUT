﻿namespace Cricut.Orders.Api.ViewModels
{
    public enum OrderStatus
    {
        Pending,
        InProgress,
        Complete
    }
}
