﻿namespace Cricut.Orders.Api.ViewModels
{
    public record NewOrderViewModel : BaseOrderViewModel
    {
    }
}
